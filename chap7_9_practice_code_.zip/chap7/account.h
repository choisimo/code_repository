#define MAX 24
#define START_ID 1

struct account {
	char name[MAX];
	int id;
	int balance;
};
