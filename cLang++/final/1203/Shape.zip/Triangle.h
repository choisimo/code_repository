//
// Created by nodove on 24. 12. 3.
//

#ifndef CODE_REPOSITORY_TRIANGLE_H
#define CODE_REPOSITORY_TRIANGLE_H

class Triangle : public Shape {
protected:
    virtual void draw();
};
#endif //CODE_REPOSITORY_TRIANGLE_H
