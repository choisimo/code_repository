//
// Created by nodove on 24. 12. 3.
//

#ifndef CODE_REPOSITORY_RECT_H
#define CODE_REPOSITORY_RECT_H

class Rect : public Shape {
protected:
    virtual void draw();
};

#endif //CODE_REPOSITORY_RECT_H
