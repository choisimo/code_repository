//
// Created by nodove on 24. 12. 3.
//

#ifndef CODE_REPOSITORY_LINE_H
#define CODE_REPOSITORY_LINE_H

class Line : public Shape {
protected:
    virtual void draw();
};

#endif //CODE_REPOSITORY_LINE_H
